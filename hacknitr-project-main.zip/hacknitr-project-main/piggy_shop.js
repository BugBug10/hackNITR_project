function() {
  document.getElementById("amtofmoney").innerHTML = document.getElementById("amtofmoney").innerHTML - amt_of_money_on_button;
}